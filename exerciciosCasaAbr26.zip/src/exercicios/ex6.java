package exercicios;

import java.util.Scanner;

public class ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int resp = 0;
		Scanner leia = new Scanner(System.in);
		
		System.out.println("================================");
		System.out.println("	JOGO DO ADIVINHA");
		System.out.println("================================");
		
		do {
			System.out.println("Digite um número inteiro: ");
			resp = leia.nextInt();
			
			if (resp !=7) {
				System.out.println("Errou, tente novamente!");
			}
			
		} while(resp !=7);
		
		System.out.println("Acertou!");
		System.out.println("\nJogo finalizado");
		System.out.println("\n================================");
		System.out.println("================================");
		
	}

}
