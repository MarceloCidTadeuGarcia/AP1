package exercicios;

import java.util.Scanner;

public class ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		float saldo = 1000, retirada;
		int resp = 3; 
		Scanner leia = new Scanner(System.in);
		
		System.out.println("================================");
		System.out.println("		CAIXA ELETRÔNICO ");
		System.out.println("================================");
		
		do {
			System.out.println("\nEscolha uma das opções abaixo");
			System.out.println("\n================================");
			System.out.println("\n1 - Ver saldo atual");
			System.out.println("\n2 - Fazer retirada");
			System.out.println("\n0 - Encerrar");
			resp = leia.nextInt();
			
			switch (resp) {
				case 1:
					System.out.println("\nSaldo atual: R$"+saldo);
				break;
				case 2:
					System.out.println("\nEscolha o valor da retirada: R$");
					retirada = leia.nextFloat();
					if (retirada <= saldo) {
					saldo = saldo - retirada;
					} else {
						System.out.println("\n================================");
						System.out.println("\nVocê não tem o saldo necessário");
						System.out.println("\n================================");
					}
					System.out.println("\nSaldo atual: R$"+saldo);
				break;
				case 0: 
					System.out.println("\nObrigado por escolher nosso banco!");
				break;					
			}			
			
		} while (saldo > 0 && resp != 0);
		
		System.out.println("\nOPERAÇÃO FINALIZADA");
		
		

	}

}
